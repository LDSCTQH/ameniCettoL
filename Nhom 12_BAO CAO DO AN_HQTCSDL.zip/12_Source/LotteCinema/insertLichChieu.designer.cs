﻿namespace LotteCinema
{
    partial class insertLichChieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbThoiGianBatDau = new System.Windows.Forms.ComboBox();
            this.dtpk_dateInsertLichChieu = new System.Windows.Forms.DateTimePicker();
            this.tb_dateFrom = new System.Windows.Forms.TextBox();
            this.cbdinhdang = new System.Windows.Forms.ComboBox();
            this.cbphim = new System.Windows.Forms.ComboBox();
            this.cbphong = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btinsert = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbThoiGianBatDau);
            this.groupBox1.Controls.Add(this.dtpk_dateInsertLichChieu);
            this.groupBox1.Controls.Add(this.tb_dateFrom);
            this.groupBox1.Controls.Add(this.cbdinhdang);
            this.groupBox1.Controls.Add(this.cbphim);
            this.groupBox1.Controls.Add(this.cbphong);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.groupBox1.Location = new System.Drawing.Point(31, 37);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(507, 224);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // cbThoiGianBatDau
            // 
            this.cbThoiGianBatDau.FormattingEnabled = true;
            this.cbThoiGianBatDau.Items.AddRange(new object[] {
            "09:30:00",
            "11:00:00",
            "13:00:00",
            "15:00:00",
            "17:00:00",
            "19:00:00",
            "21:00:00"});
            this.cbThoiGianBatDau.Location = new System.Drawing.Point(135, 136);
            this.cbThoiGianBatDau.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbThoiGianBatDau.Name = "cbThoiGianBatDau";
            this.cbThoiGianBatDau.Size = new System.Drawing.Size(125, 21);
            this.cbThoiGianBatDau.TabIndex = 13;
            this.cbThoiGianBatDau.UseWaitCursor = true;
            // 
            // dtpk_dateInsertLichChieu
            // 
            this.dtpk_dateInsertLichChieu.Location = new System.Drawing.Point(241, 85);
            this.dtpk_dateInsertLichChieu.Name = "dtpk_dateInsertLichChieu";
            this.dtpk_dateInsertLichChieu.Size = new System.Drawing.Size(20, 20);
            this.dtpk_dateInsertLichChieu.TabIndex = 12;
            this.dtpk_dateInsertLichChieu.UseWaitCursor = true;
            this.dtpk_dateInsertLichChieu.Value = new System.DateTime(2018, 12, 13, 3, 58, 34, 0);
            this.dtpk_dateInsertLichChieu.ValueChanged += new System.EventHandler(this.dtpk_dateInsertLichChieu_ValueChanged);
            // 
            // tb_dateFrom
            // 
            this.tb_dateFrom.Location = new System.Drawing.Point(135, 85);
            this.tb_dateFrom.Name = "tb_dateFrom";
            this.tb_dateFrom.Size = new System.Drawing.Size(101, 20);
            this.tb_dateFrom.TabIndex = 11;
            this.tb_dateFrom.UseWaitCursor = true;
            // 
            // cbdinhdang
            // 
            this.cbdinhdang.FormattingEnabled = true;
            this.cbdinhdang.Location = new System.Drawing.Point(358, 82);
            this.cbdinhdang.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbdinhdang.Name = "cbdinhdang";
            this.cbdinhdang.Size = new System.Drawing.Size(124, 21);
            this.cbdinhdang.TabIndex = 9;
            this.cbdinhdang.UseWaitCursor = true;
            // 
            // cbphim
            // 
            this.cbphim.FormattingEnabled = true;
            this.cbphim.Location = new System.Drawing.Point(358, 37);
            this.cbphim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbphim.Name = "cbphim";
            this.cbphim.Size = new System.Drawing.Size(124, 21);
            this.cbphim.TabIndex = 8;
            this.cbphim.UseWaitCursor = true;
            // 
            // cbphong
            // 
            this.cbphong.FormattingEnabled = true;
            this.cbphong.Location = new System.Drawing.Point(136, 39);
            this.cbphong.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbphong.Name = "cbphong";
            this.cbphong.Size = new System.Drawing.Size(124, 21);
            this.cbphong.TabIndex = 6;
            this.cbphong.UseWaitCursor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(287, 88);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Định dạng";
            this.label5.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(287, 39);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Phim";
            this.label6.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 136);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Thời gian bắt đầu";
            this.label3.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 88);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày";
            this.label2.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Phòng";
            this.label1.UseWaitCursor = true;
            // 
            // btinsert
            // 
            this.btinsert.Location = new System.Drawing.Point(428, 284);
            this.btinsert.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btinsert.Name = "btinsert";
            this.btinsert.Size = new System.Drawing.Size(82, 25);
            this.btinsert.TabIndex = 14;
            this.btinsert.Text = "Thêm";
            this.btinsert.UseVisualStyleBackColor = true;
            this.btinsert.UseWaitCursor = true;
            this.btinsert.Click += new System.EventHandler(this.btinsert_Click);
            // 
            // insertLichChieu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.btinsert);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "insertLichChieu";
            this.Text = "insertLichChieu";
            this.UseWaitCursor = true;
            this.Load += new System.EventHandler(this.insertLichChieu_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbdinhdang;
        private System.Windows.Forms.ComboBox cbphim;
        private System.Windows.Forms.ComboBox cbphong;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpk_dateInsertLichChieu;
        private System.Windows.Forms.TextBox tb_dateFrom;
        private System.Windows.Forms.Button btinsert;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbThoiGianBatDau;
    }
}